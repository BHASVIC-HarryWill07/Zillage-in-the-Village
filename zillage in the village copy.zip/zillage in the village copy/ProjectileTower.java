import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ProjectileTower here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ProjectileTower extends Actor
{
    /**
     * Act - do whatever the ProjectileTower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public ProjectileTower(){
       getImage().scale(60,60); 
    }
    public void act()
    {
        
    }
}
