import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BackgroundContrast here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BackgroundContrast extends Actor
{
    /**
     * Act - do whatever the BackgroundContrast wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public BackgroundContrast(){
        getImage().scale(45,45);
    }
    public void act()
    {
        // Add your action code here.
    }
}
