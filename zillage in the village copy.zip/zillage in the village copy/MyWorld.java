import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(10, 7, 60); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        space space = new space();
        addObject(space,2,2);
        space.setLocation(1,1);
        space space2 = new space();
        addObject(space2,2,1);
        space2.setLocation(2,1);
        space space3 = new space();
        addObject(space3,5,1);
        space3.setLocation(3,1);
        space space4 = new space();
        addObject(space4,5,1);
        space4.setLocation(4,1);
        space space5 = new space();
        addObject(space5,6,1);
        space5.setLocation(5,1);
        space space6 = new space();
        addObject(space6,7,1);
        space6.setLocation(6,1);
        space space7 = new space();
        addObject(space7,8,1);
        space7.setLocation(7,1);
        space space8 = new space();
        addObject(space8,9,1);
        space8.setLocation(9,1);
        space8.setLocation(8,1);
        space space9 = new space();
        addObject(space9,9,1);
        space space10 = new space();
        addObject(space10,2,3);
        space10.setLocation(1,2);
        space space11 = new space();
        addObject(space11,5,3);
        space11.setLocation(2,2);
        space space12 = new space();
        addObject(space12,5,2);
        space12.setLocation(3,2);
        space space13 = new space();
        addObject(space13,6,2);
        space13.setLocation(4,2);
        space space14 = new space();
        addObject(space14,6,2);
        space14.setLocation(6,2);
        space14.setLocation(5,2);
        space space15 = new space();
        addObject(space15,7,2);
        space15.setLocation(6,2);
        space space16 = new space();
        addObject(space16,8,3);
        space16.setLocation(7,2);
        space space17 = new space();
        addObject(space17,9,2);
        space17.setLocation(8,2);
        space17.setLocation(9,2);
        space17.setLocation(8,2);
        space17.setLocation(8,2);
        space space18 = new space();
        addObject(space18,9,2);
        space space19 = new space();
        addObject(space19,1,3);
        space space20 = new space();
        addObject(space20,2,3);
        space space21 = new space();
        addObject(space21,3,3);
        space space22 = new space();
        addObject(space22,5,3);
        space22.setLocation(4,3);
        space space23 = new space();
        addObject(space23,5,3);
        space space24 = new space();
        addObject(space24,6,3);
        space space25 = new space();
        addObject(space25,8,3);
        space25.setLocation(7,3);
        space space26 = new space();
        addObject(space26,9,3);
        space26.setLocation(8,3);
        space space27 = new space();
        addObject(space27,9,3);
        space space28 = new space();
        addObject(space28,1,4);
        space space29 = new space();
        addObject(space29,2,4);
        space space30 = new space();
        addObject(space30,3,4);
        space space31 = new space();
        addObject(space31,4,4);
        space space32 = new space();
        addObject(space32,5,4);
        space space33 = new space();
        addObject(space33,7,4);
        space33.setLocation(6,4);
        space space34 = new space();
        addObject(space34,7,4);
        space space35 = new space();
        addObject(space35,9,4);
        space space36 = new space();
        addObject(space36,9,4);
        space space37 = new space();
        addObject(space37,1,5);
        space space38 = new space();
        addObject(space38,2,5);
        space space39 = new space();
        addObject(space39,3,5);
        space space40 = new space();
        addObject(space40,4,5);
        space space41 = new space();
        addObject(space41,5,5);
        space space42 = new space();
        addObject(space42,6,5);
        space space43 = new space();
        addObject(space43,7,5);
        space space44 = new space();
        addObject(space44,8,5);
        space space45 = new space();
        addObject(space45,9,5);
        BackgroundContrast backgroundContrast = new BackgroundContrast();
        addObject(backgroundContrast,0,1);
        BackgroundContrast backgroundContrast2 = new BackgroundContrast();
        addObject(backgroundContrast2,0,2);
        backgroundContrast.setLocation(0,1);
        BuyMoneyTower buyMoneyTower = new BuyMoneyTower();
        addObject(buyMoneyTower,0,1);
        backgroundContrast2.setLocation(0,2);
        BuyProjectileTower buyProjectileTower = new BuyProjectileTower();
        addObject(buyProjectileTower,0,2);
        backgroundContrast2.setLocation(0,2);
        space10.setLocation(1,2);
        ProjectileTower projectileTower = new ProjectileTower();
        addObject(projectileTower,1,2);
        space10.setLocation(8,3);
        space26.setLocation(8,3);
        space26.setLocation(8,3);
        removeObject(projectileTower);
        space34.setLocation(7,4);
        space44.setLocation(8,5);
        space45.setLocation(10,5);
        space35.setLocation(8,4);
        space11.setLocation(2,2);
        space12.setLocation(3,2);
        space3.setLocation(3,1);
        space2.setLocation(2,1);
        space.setLocation(1,1);
        space11.setLocation(2,2);
        space19.setLocation(1,3);
        space28.setLocation(1,4);
        space37.setLocation(1,5);
        space38.setLocation(2,5);
        space12.setLocation(3,2);
        space3.setLocation(3,1);
        space20.setLocation(2,3);
        space21.setLocation(3,3);
        space29.setLocation(2,4);
        space.setLocation(1,1);
        space37.setLocation(1,5);
        space38.setLocation(2,5);
        space39.setLocation(3,5);
        space40.setLocation(4,5);
        space41.setLocation(5,4);
        space32.setLocation(5,5);
        space42.setLocation(6,5);
        space43.setLocation(7,5);
        space44.setLocation(8,5);
        space45.setLocation(9,5);
        space36.setLocation(9,4);
        space.setLocation(1,1);
        space2.setLocation(2,1);
        space3.setLocation(3,1);
        space4.setLocation(4,1);
        space5.setLocation(5,1);
        space6.setLocation(6,1);
        space7.setLocation(7,1);
        space8.setLocation(8,1);
        space9.setLocation(9,0);
        space9.setLocation(9,1);
        space11.setLocation(2,2);
        space12.setLocation(3,2);
        space13.setLocation(4,2);
        space14.setLocation(5,2);
        space15.setLocation(6,2);
        space16.setLocation(7,2);
        space17.setLocation(8,2);
        space18.setLocation(9,2);
        space19.setLocation(1,3);
        space20.setLocation(2,3);
        space21.setLocation(3,3);
        space22.setLocation(4,3);
        space23.setLocation(5,3);
        space24.setLocation(6,3);
        space25.setLocation(7,3);
        space10.setLocation(1,2);
    }
}   
