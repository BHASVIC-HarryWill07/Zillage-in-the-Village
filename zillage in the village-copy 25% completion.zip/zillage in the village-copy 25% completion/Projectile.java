import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class projectile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Projectile extends Actor
{
    public Projectile(){
        getImage().scale(30,15);
    }
    public void act()
    {
        move(1);
    }
    public void despawn(){
        int x = getX();
        if(x == 9){
            getWorld().removeObject(this);
        }
    }
}
