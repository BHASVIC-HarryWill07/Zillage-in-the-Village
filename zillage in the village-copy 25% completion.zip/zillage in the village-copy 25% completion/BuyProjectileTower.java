import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BuyProjectileTower here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BuyProjectileTower extends Actor
{
    public BuyProjectileTower(){
       getImage().scale(30,30);
    }
    public void act()
    {
        buyTower();
    }
    private void buyTower(){
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if(mouse != null && Greenfoot.mousePressed(this)){
            int x = mouse.getX();
            int y = mouse.getY();
            ProjectileTower projectileTower = new ProjectileTower();
            getWorld().addObject(projectileTower, x, y);
        }
    }
}
