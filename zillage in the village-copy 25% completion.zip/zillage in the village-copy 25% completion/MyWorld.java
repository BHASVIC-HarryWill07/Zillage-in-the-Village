import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(10, 7, 60); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Space space = new Space();
        addObject(space,1,1);
        Space space2 = new Space();
        addObject(space2,2,1);
        Space space3 = new Space();
        addObject(space3,3,1);
        Space space4 = new Space();
        addObject(space4,4,1);
        Space space5 = new Space();
        addObject(space5,5,1);
        Space space6 = new Space();
        addObject(space6,6,1);
        Space space7 = new Space();
        addObject(space7,7,1);
        Space space8 = new Space();
        addObject(space8,8,1);
        Space space9 = new Space();
        addObject(space9,9,1);
        Space space10 = new Space();
        addObject(space10,1,2);
        Space space11 = new Space();
        addObject(space11,2,2);
        Space space12 = new Space();
        addObject(space12,3,2);
        Space space13 = new Space();
        addObject(space13,4,2);
        Space space14 = new Space();
        addObject(space14,5,2);
        Space space15 = new Space();
        addObject(space15,6,2);
        Space space16 = new Space();
        addObject(space16,7,2);
        Space space17 = new Space();
        addObject(space17,8,2);
        Space space18 = new Space();
        addObject(space18,9,2);
        Space space19 = new Space();
        addObject(space19,1,3);
        Space space20 = new Space();
        addObject(space20,2,3);
        Space space21 = new Space();
        addObject(space21,3,3);
        Space space22 = new Space();
        addObject(space22,4,3);
        Space space23 = new Space();
        addObject(space23,5,3);
        Space space24 = new Space();
        addObject(space24,6,3);
        Space space25 = new Space();
        addObject(space25,7,3);
        Space space26 = new Space();
        addObject(space26,8,3);
        Space space27 = new Space();
        addObject(space27,9,3);
        Space space28 = new Space();
        addObject(space28,1,4);
        Space space29 = new Space();
        addObject(space29,2,4);
        Space space30 = new Space();
        addObject(space30,3,4);
        Space space31 = new Space();
        addObject(space31,4,4);
        Space space32 = new Space();
        addObject(space32,5,4);
        Space space33 = new Space();
        addObject(space33,6,4);
        Space space34 = new Space();
        addObject(space34,7,4);
        Space space35 = new Space();
        addObject(space35,8,4);
        Space space36 = new Space();
        addObject(space36,9,4);
        Space space37 = new Space();
        addObject(space37,1,5);
        Space space38 = new Space();
        addObject(space38,2,5);
        Space space39 = new Space();
        addObject(space39,3,5);
        Space space40 = new Space();
        addObject(space40,4,5);
        Space space41 = new Space();
        addObject(space41,5,5);
        Space space42 = new Space();
        addObject(space42,6,5);
        Space space43 = new Space();
        addObject(space43,7,5);
        Space space44 = new Space();
        addObject(space44,8,5);
        Space space45 = new Space();
        addObject(space45,9,5);
        BackgroundContrast backgroundContrast = new BackgroundContrast();
        addObject(backgroundContrast,0,1);
        BackgroundContrast backgroundContrast2 = new BackgroundContrast();
        addObject(backgroundContrast2,0,2);
        backgroundContrast.setLocation(0,1);
        BuyMoneyTower buyMoneyTower = new BuyMoneyTower();
        addObject(buyMoneyTower,0,1);
        backgroundContrast2.setLocation(0,2);
        BuyProjectileTower buyProjectileTower = new BuyProjectileTower();
        addObject(buyProjectileTower,0,2);
    }
}   
