import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ProjectileTower here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ProjectileTower extends Actor
{
    
    private boolean drag = false;
    private int rx = 0, ry = 0;
    private int health = 0;
    public ProjectileTower(){
       getImage().scale(60,60); 
    }
    public void act()
    {
        addTower();
        fire();
    }
    public void addTower(){
        if(Greenfoot.mouseDragged(this)){
            MouseInfo mouse = Greenfoot.getMouseInfo();
            if(!drag){
                drag = true;
                rx = getX() - mouse.getX();
                ry = getY() - mouse.getY();
            }
            else{
                setLocation(mouse.getX() + rx, mouse.getY() + ry);
            }
        }
        if(Greenfoot.mouseDragEnded(this)){
            drag = false;
        }
    }
    public void fire(){
        if(isTouching(Space.class)){
            Projectile projectile = new Projectile();
            getWorld().addObject(projectile, getX(), getY());
            sleepFor(10);
        }
        
    }
}
